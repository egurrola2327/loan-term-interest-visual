const express = require('express');
const fs = require('fs');
const csv = require('csv-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 8080;

let loanData = [];
let optionsCache = {
    terms: [],
    purposes: [],
    employment: [],
    scoreMin: 300,
    scoreMax: 850,
    environment: "Azure Production"
};

// 1. Start listening IMMEDIATELY so Azure doesn't timeout
app.listen(PORT, () => {
    console.log(`Loan Explorer running on port ${PORT}`);
});

// Explicitly point to the public directory using absolute paths
const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));
app.use(express.json());

// Fallback route to explicitly serve index.html for the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
});

// 2. Load and process the CSV dataset in the background
const csvPath = path.join(__dirname, 'loan_dataset.csv');
if (fs.existsSync(csvPath)) {
    const termsSet = new Set();
    const purposesSet = new Set();
    const employmentSet = new Set();

    fs.createReadStream(csvPath)
        .pipe(csv())
        .on('data', (row) => {
            row.credit_score = parseInt(row.credit_score, 10) || 0;
            row.loan_term = parseInt(row.loan_term, 10) || 0;
            row.interest_rate = parseFloat(row.interest_rate) || 0;
            row.loan_amount = parseFloat(row.loan_amount) || 0;
            row.loan_paid_back = parseInt(row.loan_paid_back, 10) || 0;
            row.score_bin = Math.floor(row.credit_score / 50) * 50;

            if (row.loan_term) termsSet.add(row.loan_term);
            if (row.loan_purpose) purposesSet.add(row.loan_purpose);
            if (row.employment_status) employmentSet.add(row.employment_status);

            loanData.push(row);
        })
        .on('end', () => {
            optionsCache.terms = Array.from(termsSet).sort((a, b) => a - b);
            optionsCache.purposes = Array.from(purposesSet).sort();
            optionsCache.employment = Array.from(employmentSet).sort();
            console.log(`Successfully loaded ${loanData.length} loans from CSV.`);
        });
} else {
    console.error(`Warning: loan_dataset.csv not found at ${csvPath}`);
}

// API Endpoint for Filter Options
app.get('/api/options', (req, res) => {
    res.json(optionsCache);
});

// API Endpoint for Dashboard Summary
app.get('/api/summary', (req, res) => {
    try {
        let filtered = [...loanData];

        if (req.query.f) {
            const filters = JSON.parse(req.query.f);
            if (filters.terms && filters.terms.length > 0) {
                const termInts = filters.terms.map(t => parseInt(t, 10));
                filtered = filtered.filter(row => termInts.includes(row.loan_term));
            }
            if (filters.purposes && filters.purposes.length > 0) {
                filtered = filtered.filter(row => filters.purposes.includes(row.loan_purpose));
            }
            if (filters.employment && filters.employment.length > 0) {
                filtered = filtered.filter(row => filters.employment.includes(row.employment_status));
            }
            if (filters.scoreMin !== undefined && filters.scoreMax !== undefined) {
                filtered = filtered.filter(row => row.credit_score >= filters.scoreMin && row.credit_score <= filters.scoreMax);
            }
        }

        if (filtered.length === 0) {
            return res.json({ empty: true, message: "No borrowers match these filters." });
        }

        const totalBorrowers = filtered.length;
        const avgInterestRate = filtered.reduce((acc, row) => acc + row.interest_rate, 0) / totalBorrowers;
        const avgLoanAmount = filtered.reduce((acc, row) => acc + row.loan_amount, 0) / totalBorrowers;
        const paidBackRate = (filtered.reduce((acc, row) => acc + row.loan_paid_back, 0) / totalBorrowers) * 100;

        const purposeMap = {};
        filtered.forEach(row => {
            const p = row.loan_purpose || 'Other';
            if (!purposeMap[p]) purposeMap[p] = { sumRate: 0, count: 0 };
            purposeMap[p].sumRate += row.interest_rate;
            purposeMap[p].count += 1;
        });

        const purposeArray = Object.keys(purposeMap).map(p => ({
            name: p,
            mean: purposeMap[p].sumRate / purposeMap[p].count,
            count: purposeMap[p].count
        })).sort((a, b) => a.mean - b.mean);

        res.json({
            empty: false,
            kpis: {
                borrowers: totalBorrowers,
                avgRate: avgInterestRate,
                avgAmount: avgLoanAmount,
                paidBack: paidBackRate
            },
            purpose: purposeArray
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});